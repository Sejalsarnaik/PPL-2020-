int N;

int main()
{
    int i, a = 10;
    for(i= 0; i < 4; i++)
    {
        a = a + N;
    };
    return a;
}

